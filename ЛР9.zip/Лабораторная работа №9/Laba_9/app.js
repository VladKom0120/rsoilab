const mongoose = require('mongoose');
const express = require('express');
const jsonParser = express.json();

const findAllRecords = require('./routes/findAllRecords');
const findOneRecord = require('./routes/findOneRecord');
const createRecord = require('./routes/createRecord');
const editRecord = require('./routes/editRecord');
const deleteRecord = require('./routes/deleteRecord');
const filterRecords = require('./routes/filterRecords');
const editAllRecords = require('./routes/editAllRecords');

const app = express();

app.use(express.static(__dirname + '/public'));

mongoose.connect('mongodb://localhost:27017/clocksdb', { useNewUrlParser: true }, function (err) {
    if (err) {
        return console.log(err);
    }
    app.listen(3000, function () {
        console.log('Сервер ожидает подключения...');
    });
});

app.get('/api/clocks', function (req, res) {
    findAllRecords(req, res);
});

app.get('/api/clocks/:id', function (req, res) {
    findOneRecord(req, res);
});

app.post('/api/clocks', jsonParser, function (req, res) {
    createRecord(req, res);
});

app.put('/api/clocks', jsonParser, function (req, res) {
    editRecord(req, res);
});

app.delete('/api/clocks/:id', function (req, res) {
    deleteRecord(req, res);
});

app.get('/api/filterClocks', function (req, res) {
    filterRecords(req, res);
});

app.get('/api/editManufacturer', function (req, res) {
    editAllRecords(req, res);
});
