const Clock = require('../model/clock');

function createRecord(req, res) {
    if (!req.body) {
        return res.sendStatus(400);
    }

    let clockName = req.body.name;
    let clockType = req.body.type;
    let clockManufacturer = req.body.manufacturer;
    let clockPrice = req.body.price;
    let clock = new Clock({ name: clockName, type: clockType, manufacturer: clockManufacturer, price: clockPrice });

    clock.save(function (err) {
        if (err) {
            return res.sendStatus(400);
        }
        res.send(clock);
    });
};

module.exports = createRecord;