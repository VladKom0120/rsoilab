const Clock = require('../model/clock');

function editAllRecords(req, res) {
    let manufacturer = req.query.manufacturer;
    Clock.updateMany( {}, { $set: {manufacturer: manufacturer}}, function (err, clocks) {
        if (err) {
            return res.sendStatus(400);
        }
    });
};

module.exports = editAllRecords;