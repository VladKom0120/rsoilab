const Clock = require('../model/clock');

function findOneRecord(req, res) {
    let id = req.params.id;
    Clock.findOne({ _id: id }, function (err, clock) {
        if (err) {
            return res.sendStatus(400);
        }
        res.send(clock);
    });
};

module.exports = findOneRecord;