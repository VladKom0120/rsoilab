const Clock = require('../model/clock');

function filterRecords(req, res) {
    let price = req.query.price;
    Clock.find({ price: { $lte: price} }, function (err, clocks) {
        if (err) {
            return res.sendStatus(400);
        }
        res.send(clocks);
    });
};

module.exports = filterRecords;