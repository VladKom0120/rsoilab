const Clock = require('../model/clock');

function findAllRecords(req, res) {
    Clock.find({}, function (err, clocks) {
        if (err) {
            return res.sendStatus(400);
        }
        res.send(clocks)
    });
};

module.exports = findAllRecords;