const Clock = require('../model/clock');

function editRecord(req, res) {
    if (!req.body) {
        return res.sendStatus(400);
    }

    let id = req.body.id;
    let clockName = req.body.name;
    let clockType = req.body.type;
    let clockManufacturer = req.body.manufacturer;
    let clockPrice = req.body.price;
    let newClock = { name: clockName, type: clockType, manufacturer: clockManufacturer, price: clockPrice };

    Clock.findOneAndUpdate({ _id: id }, newClock, { new: true }, function (err, clock) {
        if (err) {
            return res.sendStatus(400);
        }
        res.send(clock);
    });
};

module.exports = editRecord;