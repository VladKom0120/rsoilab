const Clock = require('../model/clock');

function deleteRecord(req, res) {
    let id = req.params.id;
    Clock.findByIdAndDelete(id, function (err, clock) {
        if (err) {
            return res.sendStatus(400);
        }
        res.send(clock);
    });
};

module.exports = deleteRecord;