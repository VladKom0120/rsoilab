function getClocks() {
    $.ajax({
        url: '/api/clocks',
        type: 'GET',
        contentType: 'application/json',
        success: function (clocks) {
            document.getElementsByClassName('table__tbody')[0].innerHTML = "";
            let rows = "";
            $.each(clocks, function (index, clock) {
                rows += addRow(clock);
            })
            $(".table__tbody").append(rows);
        }
    });
}

function displayRecord(id) {
    $.ajax({
        url: '/api/clocks/' + id,
        type: 'GET',
        contentType: 'application/json',
        success: function (clock) {
            document.clockForm.id.value = clock._id;
            document.clockForm.name.value = clock.name;
            document.clockForm.type.value = clock.type;
            document.clockForm.manufacturer.value = clock.manufacturer;
            document.clockForm.price.value = clock.price;
        }
    });
}

function createClock(clockName, clockType, clockManufacturer, clockPrice) {
    $.ajax({
        url: 'api/clocks',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            name: clockName,
            type: clockType,
            manufacturer: clockManufacturer,
            price: clockPrice
        }),
        success: function (clock) {
            $(".table__tbody").append(addRow(clock));
        }
    })
}

function editClock(clockId, clockName, clockType, clockManufacturer, clockPrice) {
    $.ajax({
        url: 'api/clocks',
        type: 'PUT',
        contentType: 'application/json',
        data: JSON.stringify({
            id: clockId,
            name: clockName,
            type: clockType,
            manufacturer: clockManufacturer,
            price: clockPrice
        }),
        success: function (clock) {
            $("tr[data-rowid='" + clock._id + "']").replaceWith(addRow(clock));
        }
    })
}

function deleteClock(id) {
    $.ajax({
        url: 'api/clocks/' + id,
        type: 'DELETE',
        contentType: 'application/json',
        success: function (clock) {
            $("tr[data-rowid='" + clock._id + "']").remove();
        }
    })
}

function printRecords(price) {
    $.ajax({
        url: '/api/filterClocks',
        type: 'GET',
        contentType: 'application/json',
        data: { price: price} ,
        success: function (clocks) {
            document.getElementsByClassName('table__tbody')[0].innerHTML = "";
            let rows = "";
            $.each(clocks, function (index, clock) {
                rows += addRow(clock);
            })
            $(".table__tbody").append(rows);
        }
    });
}

function editManufacturer(manufacturer) {
    $.ajax({
        url: '/api/editManufacturer',
        type: 'GET',
        contentType: 'application/json',
        data: { manufacturer: manufacturer}
    });
}

function addRow(clock) {
    return `<tr data-rowid="${clock._id}">
             <td class="table__td">${clock._id}</td>
             <td class="table__td">${clock.name}</td>
             <td class="table__td">${clock.type}</td>
             <td class="table__td">${clock.manufacturer}</td>
             <td class="table__td">${clock.price}</td>
             <td class="table__td"><a class="link" id="editLink" data-id="${clock._id}">Изменить</a> | 
             <a class="link" id="removeLink" data-id="${clock._id}">Удалить</a></td>
            </tr>`;
}

document.getElementById('submit-button').addEventListener('click', function () {
    let id = document.clockForm.id.value;
    let name = document.clockForm.name.value;
    let type = document.clockForm.type.value;
    let manufacturer = document.clockForm.manufacturer.value;
    let price = document.clockForm.price.value;
    if (id == 0) {
        createClock(name, type, manufacturer, price);
    } else {
        editClock(id, name, type, manufacturer, price);
    }
});

document.getElementById('show-button').addEventListener('click', function (event) {
    event.preventDefault();
    getClocks();
});

document.getElementById('print-button').addEventListener('click', function (event) {
    event.preventDefault();
    document.getElementsByClassName('table__tbody')[0].innerHTML = "";
    let newPrice = document.clockForm.newPrice.value;
    printRecords(newPrice);
});

document.getElementById('replace-button').addEventListener('click', function (event) {
    event.preventDefault();
    document.getElementsByClassName('table__tbody')[0].innerHTML = "";
    let newManufacturer = document.clockForm.newManufacturer.value;
    editManufacturer(newManufacturer);
    getClocks();
});

$('body').on('click', '#editLink', function () {
    let id = $(this).data('id');
    displayRecord(id);
});

$('body').on('click', '#removeLink', function () {
    let id = $(this).data('id');
    deleteClock(id);
});

getClocks();